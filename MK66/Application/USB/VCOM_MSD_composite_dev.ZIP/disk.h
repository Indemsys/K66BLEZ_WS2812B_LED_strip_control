#ifndef _DISK_H
  #define _DISK_H  1

  #include "usb_descriptor.h"

  #define RAM_DISK_APP            (1)
  #define SD_CARD_APP             (0)

  #if RAM_DISK_APP

/* Length of Each Logical Address Block */
    #define LENGTH_OF_EACH_LAB              (512)

/* total number of logical blocks present */
    #define TOTAL_LOGICAL_ADDRESS_BLOCKS    (48)

/* Net Disk Size */
    #define DISK_SIZE                       (LENGTH_OF_EACH_LAB * TOTAL_LOGICAL_ADDRESS_BLOCKS)
  #endif

  #define LOGICAL_UNIT_SUPPORTED          (1)

  #define SUPPORT_DISK_LOCKING_MECHANISM  (0) /*1: TRUE; 0:FALSE*/
/* If Implementing Disk Drive then configure the macro below as TRUE,
 otherwise keep it False(say for Hard Disk)*/
  #define IMPLEMENTING_DISK_DRIVE         (0) /*1: TRUE; 0:FALSE*/

//#define MSD_RECV_BUFFER_SIZE            (BULK_OUT_ENDP_PACKET_SIZE)
//#define MSD_SEND_BUFFER_SIZE            (BULK_IN_ENDP_PACKET_SIZE)

  #define MSD_RECV_BUFFER_SIZE            (512)
  #define MSD_SEND_BUFFER_SIZE            (512)


typedef struct _disk_variable_struct
{
  msd_handle_t app_handle;
  uint32_t start_app;
  uint16_t speed;
  #if RAM_DISK_APP
  /* disk space reserved */
  uint8_t storage_disk[DISK_SIZE];
  #endif
  uint8_t disk_lock;
} disk_struct_t;

void msc_disk_preinit(void);
void msc_disk_init(void *param);
uint8_t Disk_USB_App_Class_Callback
(uint8_t event_type,
 uint16_t value,
 uint8_t **data,
 uint32_t *size,
 void *arg
);

void Disk_USB_App_Device_Callback(uint8_t event_type, void *val, void *arg);
void msc_disk_task(void);
#endif

/* EOF */
