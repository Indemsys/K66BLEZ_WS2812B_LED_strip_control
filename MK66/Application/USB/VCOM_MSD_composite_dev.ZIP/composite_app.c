#include "usb_device_config.h"
#include "usb.h"
#include "usb_device_stack_interface.h"
#include "virtual_com.h"    /* CDC Application Header File */
#include "disk.h"           /* MSD Application Header File */
#include "usb_class_composite.h"
#include "composite_app.h"

#if ! USBCFG_DEV_COMPOSITE
  #error This application requires USBCFG_DEV_COMPOSITE defined non-zero in usb_device_config.h. Please recompile usbd with this option.
#endif

extern usb_desc_request_notify_struct_t desc_callback;
composite_device_struct_t *g_composite_device = NULL;


/*------------------------------------------------------------------------------


 ------------------------------------------------------------------------------*/
void USB_task(unsigned int initial_data)
{
  class_config_struct_t *cdc_vcom_config_callback_handle;
  class_config_struct_t *msc_disk_config_callback_handle;

  cdc_vcom_preinit();
  msc_disk_preinit();


  if (NULL == g_composite_device)
  {
    g_composite_device = OS_Mem_alloc_uncached_zero(sizeof(composite_device_struct_t));
  }

  /* cdc vcom device */
  cdc_vcom_config_callback_handle = &g_composite_device->composite_device_config_list[CDC_VCOM_INTERFACE_INDEX];
  cdc_vcom_config_callback_handle->composite_application_callback.callback = VCom_USB_App_Device_Callback;
  cdc_vcom_config_callback_handle->composite_application_callback.arg = &g_composite_device->cdc_vcom;
  cdc_vcom_config_callback_handle->class_specific_callback.callback = (usb_class_specific_handler_func)VCom_USB_App_Class_Callback;
  cdc_vcom_config_callback_handle->class_specific_callback.arg = &g_composite_device->cdc_vcom;
  cdc_vcom_config_callback_handle->desc_callback_ptr = &desc_callback;
  cdc_vcom_config_callback_handle->type = USB_CLASS_CDC;

  /* msc disk device */
  msc_disk_config_callback_handle = &g_composite_device->composite_device_config_list[MSC_DISK_INTERFACE_INDEX];
  msc_disk_config_callback_handle->composite_application_callback.callback = Disk_USB_App_Device_Callback;
  msc_disk_config_callback_handle->composite_application_callback.arg = &g_composite_device->msc_disk;
  msc_disk_config_callback_handle->class_specific_callback.callback = (usb_class_specific_handler_func)Disk_USB_App_Class_Callback;
  msc_disk_config_callback_handle->class_specific_callback.arg = &g_composite_device->msc_disk;
  msc_disk_config_callback_handle->desc_callback_ptr = &desc_callback;
  msc_disk_config_callback_handle->type = USB_CLASS_MSC;
  OS_Mem_zero(&g_composite_device->msc_disk, sizeof(disk_struct_t));

  g_composite_device->composite_device_config_callback.count = 2;
  g_composite_device->composite_device_config_callback.class_app_callback = g_composite_device->composite_device_config_list;

  msc_disk_init(&g_composite_device->msc_disk);

  /* Initialize the USB interface */
  USB_Composite_Init(CONTROLLER_ID, &g_composite_device->composite_device_config_callback, &g_composite_device->composite_device);

  g_composite_device->cdc_vcom = (cdc_handle_t)g_composite_device->composite_device_config_list[CDC_VCOM_INTERFACE_INDEX].class_handle;
  g_composite_device->msc_disk.app_handle = (msd_handle_t)g_composite_device->composite_device_config_list[MSC_DISK_INTERFACE_INDEX].class_handle;
  cdc_vcom_init(&g_composite_device->cdc_vcom);

  while (TRUE)
  {
    msc_disk_task();
    cdc_vcom_task();
  }

}

